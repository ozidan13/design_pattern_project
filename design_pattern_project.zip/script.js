/**
 * SYSTEM LOGGER & TOASIFICATIONS
 */
const Logger = {
    log: (message, patternName) => {
        // 1. Add to the hidden/minimized log panel
        const consoleEl = document.getElementById('sys-log');
        const entry = document.createElement('div');
        entry.className = 'log-entry';
        entry.innerHTML = `<span class="log-pattern">[${patternName}]</span> ${message}`;
        consoleEl.prepend(entry);

        // 2. Show a Toast Notification
        Toast.show(message, patternName);
    }
};

const Toast = {
    show: (msg, title) => {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.innerHTML = `
            <div>
                <div class="toast-msg">${title} Action</div>
                <span class="toast-meta">${msg}</span>
            </div>
            <span>→</span>
        `;
        container.appendChild(toast);

        // Remove after 4 seconds
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100%)';
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }
};

/* ==========================================================================
    1. SINGLETON PATTERN (Lecture 2)
    ========================================================================== */
const Cart = (function () {
    let instance;

    function createInstance() {
        const items = [];

        return {
            addItem: function (product) {
                items.push(product);
                this.updateUI();
                Logger.log(`Added "${product.getName()}" to Cart`, "Singleton");
            },
            getItems: () => items,
            getTotal: function () {
                return items.reduce((sum, item) => sum + item.getPrice(), 0);
            },
            clear: function () {
                items.length = 0;
                this.updateUI();
            },
            updateUI: function () {
                document.getElementById('cart-count').innerText = items.length;
                document.getElementById('cart-total').innerText = this.getTotal().toFixed(2);

                // Animate cart
                const cartEl = document.getElementById('cart-status');
                cartEl.style.transform = 'scale(1.1)';
                setTimeout(() => cartEl.style.transform = 'scale(1)', 200);
            }
        };
    }

    return {
        getInstance: function () {
            if (!instance) {
                instance = createInstance();
            }
            return instance;
        }
    };
})();


/* ==========================================================================
    CORE PRODUCT INTERFACE
    ========================================================================== */
class Product {
    getName() { throw new Error("Method 'getName()' must be implemented."); }
    getPrice() { throw new Error("Method 'getPrice()' must be implemented."); }
}


/* ==========================================================================
    2. ABSTRACT FACTORY PATTERN (Lecture 4)
    ========================================================================== */

// Concrete Products
class FruitLaptop extends Product {
    getName() { return "APPLE MacBook Pro"; }
    getPrice() { return 2000; }
}
class FruitPhone extends Product {
    getName() { return "APPLE iPhone 15"; }
    getPrice() { return 1000; }
}

class RoboLaptop extends Product {
    getName() { return "SAMSUNG ThinkPad"; }
    getPrice() { return 1500; }
}
class RoboPhone extends Product {
    getName() { return "SAMSUNG Galaxy S24"; }
    getPrice() { return 900; }
}

// The Abstract Factory Interface
class TechFactory {
    createLaptop() { }
    createPhone() { }
}

// Concrete Factory 1
class FruitFactory extends TechFactory {
    createLaptop() { return new FruitLaptop(); }
    createPhone() { return new FruitPhone(); }
}

// Concrete Factory 2
class RoboFactory extends TechFactory {
    createLaptop() { return new RoboLaptop(); }
    createPhone() { return new RoboPhone(); }
}


/* ==========================================================================
    3. BUILDER PATTERN (Lecture 5)
    ========================================================================== */
class CustomPC extends Product {
    constructor() {
        super();
        this.parts = [];
        this.cost = 0;
    }
    addPart(name, price) {
        this.parts.push(name);
        this.cost += price;
    }
    getName() { return `Custom PC (${this.parts.join(', ')})`; }
    getPrice() { return this.cost; }
}

class PCBuilder {
    constructor() {
        this.pc = new CustomPC();
    }
    addCPU(type, price) {
        this.pc.addPart(type, price);
        return this;
    }
    addGPU() {
        this.pc.addPart("RTX 4090 GPU", 500);
        return this;
    }
    addRAM() {
        this.pc.addPart("32GB RAM", 100);
        return this;
    }
    addRGB() {
        this.pc.addPart("RGB Lights", 50);
        return this;
    }
    build() {
        return this.pc;
    }
}


/* ==========================================================================
    4. COMPOSITE PATTERN (Lecture 8)
    ========================================================================== */
class ProductBundle extends Product {
    constructor(name) {
        super();
        this.name = name;
        this.children = [];
    }

    add(product) {
        this.children.push(product);
    }

    getName() {
        return `${this.name} [Contains: ${this.children.length} items]`;
    }

    getPrice() {
        let total = 0;
        this.children.forEach(child => {
            total += child.getPrice();
        });
        return total * 0.9;
    }
}


/* ==========================================================================
    5. ADAPTER PATTERN (Lecture 6)
    ========================================================================== */
class LegacyInventoryItem {
    constructor(name, costInCents) {
        this.sku = name;
        this.pennies = costInCents;
    }
    getSKU() { return this.sku; }
    getCostInCents() { return this.pennies; }
}

class LegacyAdapter extends Product {
    constructor(legacyItem) {
        super();
        this.legacyItem = legacyItem;
    }

    getName() {
        return this.legacyItem.getSKU() + " (Clearance)";
    }

    getPrice() {
        return this.legacyItem.getCostInCents() / 100;
    }
}


/* ==========================================================================
    6. BRIDGE PATTERN (Lecture 7)
    ========================================================================== */
class Carrier {
    ship(itemNames) { throw new Error("ship() undefined"); }
}

class FedEx extends Carrier {
    ship(itemNames) { return `FedEx Plane carrying: ${itemNames}`; }
}
class UPS extends Carrier {
    ship(itemNames) { return `UPS Brown Truck carrying: ${itemNames}`; }
}
class DHL extends Carrier {
    ship(itemNames) { return `DHL Cargo Ship carrying: ${itemNames}`; }
}

class Delivery {
    constructor(carrier) {
        this.carrier = carrier;
    }
    deliver(items) { }
}

class StandardDelivery extends Delivery {
    deliver(items) {
        Logger.log(`Standard: ${this.carrier.ship(items)}`, "Bridge");
        return "Arrives in 5-7 days";
    }
}
class ExpressDelivery extends Delivery {
    deliver(items) {
        Logger.log(`EXPRESS: ${this.carrier.ship(items)}`, "Bridge");
        return "Arrives Tomorrow!";
    }
}


/* ==========================================================================
    7. FACTORY METHOD PATTERN (Lecture 3)
    ========================================================================== */
class PaymentProcessor {
    pay(amount) { }
}

class CreditCardProcessor extends PaymentProcessor {
    pay(amount) { Logger.log(`Charged $${amount} to Visa/Mastercard.`, "Factory Method"); }
}

class PayPalProcessor extends PaymentProcessor {
    pay(amount) { Logger.log(`Redirected to PayPal for $${amount}.`, "Factory Method"); }
}

class PaymentFactory {
    static createProcessor(type) {
        if (type === 'credit') return new CreditCardProcessor();
        if (type === 'paypal') return new PayPalProcessor();
        throw new Error("Unknown payment type");
    }
}


/* ==========================================================================
    APPLICATION LOGIC (Controller)
    ========================================================================== */
const app = {

    // Abstract Factory Usage
    renderBrandProducts: (brandType) => {
        let factory;
        if (brandType === 'Fruit') factory = new FruitFactory();
        else factory = new RoboFactory();

        Logger.log(`Initialized ${brandType}Factory. Creating family...`, "Abstract Factory");

        const laptop = factory.createLaptop();
        const phone = factory.createPhone();

        // Helper to guess icon
        const lapIcon = brandType === 'Fruit' ? '💻' : '⚫';
        const phoneIcon = brandType === 'Fruit' ? '📱' : '📲';
        const accentColor = brandType === 'Fruit' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(6, 182, 212, 0.1)';

        const container = document.getElementById('brand-products');
        container.innerHTML = `
    <div class="card" style="border-top: 4px solid ${brandType === 'Fruit' ? '#a855f7' : '#06b6d4'}">
        <div class="card-image-placeholder" style="background: ${accentColor}">${lapIcon}</div>
        <h3>${laptop.getName()}</h3>
        <div class="price">$${laptop.getPrice()}</div>
        <button onclick="Cart.getInstance().addItem({ getName: () => '${laptop.getName()}', getPrice: () => ${laptop.getPrice()} })">Add to Cart</button>
    </div>
    <div class="card" style="border-top: 4px solid ${brandType === 'Fruit' ? '#a855f7' : '#06b6d4'}">
        <div class="card-image-placeholder" style="background: ${accentColor}">${phoneIcon}</div>
        <h3>${phone.getName()}</h3>
        <div class="price">$${phone.getPrice()}</div>
        <button onclick="Cart.getInstance().addItem({ getName: () => '${phone.getName()}', getPrice: () => ${phone.getPrice()} })">Add to Cart</button>
    </div>
`;
    },

    // Builder Usage
    buildAndAddPC: () => {
        Logger.log("Starting PC Builder...", "Builder");

        const builder = new PCBuilder();
        const cpuType = document.querySelector('input[name="cpu"]:checked').value;
        const cpuPrice = cpuType.includes("High-End") ? 300 : 150;

        builder.addCPU(cpuType, cpuPrice);

        if (document.getElementById('opt-gpu').checked) builder.addGPU();
        if (document.getElementById('opt-ram').checked) builder.addRAM();
        if (document.getElementById('opt-rgb').checked) builder.addRGB();

        const finalPC = builder.build();
        Cart.getInstance().addItem(finalPC);
    },

    // Composite Usage
    addBundle: () => {
        const laptop = new FruitLaptop();
        const phone = new FruitPhone();
        const charger = { getName: () => "Fast Charger", getPrice: () => 50 };

        const bundle = new ProductBundle("Student Starter Pack");
        bundle.add(laptop);
        bundle.add(phone);
        bundle.add(charger);

        Logger.log(`Created Composite Bundle.`, "Composite");
        Cart.getInstance().addItem(bundle);
    },

    // Adapter Usage
    addLegacyItem: () => {
        const oldItem = new LegacyInventoryItem("Floppy Disk 3.5", 500);
        const adaptedItem = new LegacyAdapter(oldItem);

        Logger.log(`Adapting legacy item...`, "Adapter");
        Cart.getInstance().addItem(adaptedItem);
    },

    // Bridge & Factory Method Usage
    processCheckout: () => {
        const cart = Cart.getInstance();
        if (cart.getItems().length === 0) {
            Toast.show("Your cart is empty!", "Checkout Failed");
            return;
        }

        // Bridge
        const speed = document.getElementById('ship-speed').value;
        const carrierName = document.getElementById('ship-carrier').value;

        let carrierImpl;
        switch (carrierName) {
            case 'fedex': carrierImpl = new FedEx(); break;
            case 'ups': carrierImpl = new UPS(); break;
            case 'dhl': carrierImpl = new DHL(); break;
        }

        let deliveryRefined;
        if (speed === 'standard') deliveryRefined = new StandardDelivery(carrierImpl);
        else deliveryRefined = new ExpressDelivery(carrierImpl);

        const itemsList = cart.getItems().map(i => i.getName()).join(", ");
        const deliveryStatus = deliveryRefined.deliver(itemsList);

        // Factory Method
        const payMethod = document.getElementById('payment-method').value;
        const processor = PaymentFactory.createProcessor(payMethod);
        processor.pay(cart.getTotal());

        alert(`Order Placed!\n\nShipping: ${deliveryStatus}\nVia: ${carrierName.toUpperCase()}\n\nThank you for shopping at TechPattern!`);
        cart.clear();
    }
};

// Initialize
app.renderBrandProducts('Fruit');
